<?php 
// Translation strings
__('Home Page', 'framework');
__('Blog', 'framework');
__('Blog (alternate)', 'framework');
__('Single Post', 'framework');
__('Page', 'framework');
__('Portfolio', 'framework');
?>