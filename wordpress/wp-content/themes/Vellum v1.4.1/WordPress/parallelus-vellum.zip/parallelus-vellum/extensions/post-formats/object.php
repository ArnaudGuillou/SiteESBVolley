<?php
class Post_Formats_Object extends Runway_Object {

} ?>