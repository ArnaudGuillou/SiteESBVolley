<?php
require dirname( __FILE__ ) . '/class-tgm-updater-config.php';
require dirname( __FILE__ ) . '/class-tgm-updater.php';

?>