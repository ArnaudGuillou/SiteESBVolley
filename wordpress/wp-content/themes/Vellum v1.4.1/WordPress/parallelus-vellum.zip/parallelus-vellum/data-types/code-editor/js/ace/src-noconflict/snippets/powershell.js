ace.define('ace/snippets/powershell', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "powershell";

});
