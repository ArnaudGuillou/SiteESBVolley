<br>

<p>
	<?php _e("The settings applied by this feature could be dangerous to use on a Runway child theme. The Runway development environment is unique in how it handles Options Pages, Layouts and other dynamic forms. Starter kits overwrite these database values and because of a Runway child theme's unique structure you could lose modifications made in the development environment. It is best to only use this features with a standalone theme or a child theme outside the Runway framework.", 'framework'); ?>
</p>